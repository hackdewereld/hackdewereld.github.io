#include <stdio.h>
#include <string.h>
#include <stdlib.h>

void send_message(char *username, char *message) {
    char buffer[128];
    printf("%p\n", buffer);
    int len = snprintf(buffer, sizeof(buffer), "Username: %s\n", username);
    strncat(buffer, message, sizeof(buffer) - len - 1);
    printf("Delivering message...\n");
}

int main(int argc, char *argv[]) {
    if (argc < 3) {
        printf("syntax: %s username message\n", argv[0]);
        exit(-1);
    }
    send_message(argv[1], argv[2]);
}
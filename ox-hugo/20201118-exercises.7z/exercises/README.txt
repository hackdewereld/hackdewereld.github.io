Welcome to meetup 0x08 of Hack The Box NL. Below are the requirements for this workshop, compilation instructions and setup instructions.

Requirements:
  * nasm
  * gdb (optionally pwndbg)
  * A code editor
  * Python 3

Setup:
1. Disable ASLR:
   echo 0 > /proc/sys/kernel/randomize_va_space

Compilation:
gcc -fno-stack-protector -z execstack -no-pie vulnX.c -o vulnX
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

void greet(char *name) {
    char buffer[128];
    printf("buffer: %p\n", buffer);
    strcpy(buffer, name);
    printf("Hello, %s!\n", buffer);
}

int main(int argc, char *argv[]) {
    if (argc < 2) {
        printf("syntax: %s name\n", argv[0]);
        exit(-1);
    }
    greet(argv[1]);
}